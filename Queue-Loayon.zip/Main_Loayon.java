
class Main{
    public static void main(String[] args) {
       Queue aq = new Queue(10);

		aq.enQ(5);
		aq.enQ(13);
		aq.enQ(12);
		aq.enQ(18);
		aq.enQ(55);
		aq.enQ(6);

		aq.showQ();
		System.out.println( "PeekRear: " + aq.stum() );
    }
    
}
